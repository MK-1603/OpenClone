# OpenClone v2.0.0 — Universal AI Engineering Plugin

**Official Production Plugin Package for Google Antigravity, Claude, ChatGPT, Cursor, and VS Code**  
*Version: 2.0.0 | Standard: AISDF Universal AI Software Development Framework*

---

## What Is Included in This Plugin

This self-contained plugin package equips any AI coding assistant or IDE with the complete OpenClone engineering standard:

- **18 Specialized Engineering Skills:** Anti-AI-slop design governance (Taste Skill v2.6.0), Universal Project Intelligence, Product Discovery, Architecture Design, Requirements Engineering, Security Baselines, and Testing/Verification.
- **16 Specialist Workforce Agents:** Orchestrator, Product Architect, Requirements Agent, Frontend Engineer, Backend Engineer, Database Engineer, Security Reviewer, Test Automation Engineer, and Independent Verifier.
- **4 Deterministic Operating Rules:** AGENTS.md, Anti-Slop, Cryptographic Evidence, and SaaS Security Baseline.
- **Universal Master Prompt Template:** `OPENCLONE-UNIVERSAL-MASTER-PROMPT-TEMPLATE.md` enforcing Phase 0 Sets A, B, C, D and human approval gates.
- **22 Model Context Protocol (MCP) Tools:** Exposing project classification, architecture blueprinting, brand engineering, model routing, and workforce governance.

---

## Installation Guide for All AI Tools

### 1. Google Antigravity
You can install this plugin directly via the Antigravity CLI or UI:

**Via CLI (Direct URL or Path):**
```bash
# Direct from GitHub:
agy plugin install https://github.com/MK-1603/OpenClone

# Or from this unzipped folder:
agy plugin install ./openclone-plugin
```

**Via Antigravity UI:**
1. Open Antigravity Settings ➔ **Plugins**.
2. Click **Install Plugin from Directory** or **Install from Archive**.
3. Select this folder (or `openclone-plugin-v2.0.0.zip`).
4. All 18 skills, 16 agents, and MCP tools are immediately activated.

---

### 2. Claude Desktop & Claude Code

#### A. Claude Code (CLI)
Run a single command to add OpenClone as a background MCP plugin:
```bash
pip install git+https://github.com/MK-1603/OpenClone.git
claude mcp add openclone python -m openclone.mcp.server
```

#### B. Claude Desktop (GUI App)
1. Open Claude Desktop Settings ➔ **Developer** ➔ **Edit Config**.
2. Add the following to your `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "openclone": {
      "command": "python",
      "args": ["-m", "openclone.mcp.server"]
    }
  }
}
```
*(Ensure `pip install git+https://github.com/MK-1603/OpenClone.git` has been run).*

---

### 3. ChatGPT (Custom GPT & Actions)

Connect OpenClone tools to any ChatGPT Custom GPT:

1. Open ChatGPT ➔ **Explore GPTs** ➔ **Create a GPT** ➔ **Configure**.
2. **Name:** `OpenClone Software Architect`
3. **Instructions:** Copy the content from `prompts/custom-gpt-instructions.md`.
4. **Actions (API Tools):**
   * Click **Create new action**.
   * Under **Schema**, paste the content from `adapters/chatgpt_openapi.json` (or import URL: `https://raw.githubusercontent.com/MK-1603/OpenClone/main/global/hosts/chatgpt/openapi.json`).
5. Save and publish. ChatGPT now has access to all OpenClone tools.

---

### 4. Cursor & Windsurf

1. Install the OpenClone package globally:
   ```bash
   pip install git+https://github.com/MK-1603/OpenClone.git
   ```
2. In Cursor, open **Settings** ➔ **Features** ➔ **MCP Servers** (or edit `~/.cursor/mcp.json`):
   ```json
   {
     "mcpServers": {
       "openclone": {
         "command": "python",
         "args": ["-m", "openclone.mcp.server"]
       }
     }
   }
   ```
3. Copy `rules/openclone.mdc` into your project's `.cursor/rules/` directory to enforce anti-slop and evidence rules in editor chats.

---

### 5. VS Code (Via MCP or Extension)

1. Ensure the Python environment has `openclone` installed (`pip install git+https://github.com/MK-1603/OpenClone.git`).
2. Add `adapters/vscode_mcp.json` settings to your `.vscode/settings.json` or MCP manager.
3. Open any workspace and call OpenClone tools from your AI assistant.

---

## Verification Quick Check
Verify that the OpenClone engine is active:
```bash
python -c "import openclone; print('OpenClone v' + openclone.__version__ + ' active')"
```

---
*License: MIT | Copyright (c) 2026 OpenClone Contributors*
